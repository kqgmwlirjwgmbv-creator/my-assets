# features/play.py
from PyQt5.QtWidgets import QLabel
from PyQt5.QtCore import Qt, QPropertyAnimation, QPoint, QEasingCurve
from PyQt5.QtWidgets import QGraphicsOpacityEffect


class PlayWindow:
    """玩耍功能：点击时在宠物身上显示‘心情 +3’动画"""

    def __init__(self, pet_ref):
        self.pet_ref = pet_ref

    def show_play_effect(self):
        """显示心情 +3 漂浮文字"""
        if not self.pet_ref:
            return

        label = QLabel("心情 +3", self.pet_ref)
        label.setAttribute(Qt.WA_TransparentForMouseEvents)
        label.setAlignment(Qt.AlignCenter)
        label.setStyleSheet("""
            QLabel {
                color: #ff6699;
                font-size: 18px;
                font-weight: bold;
                text-shadow: 1px 1px 2px black;
            }
        """)

        # 居中偏上
        start_pos = self.pet_ref.rect().center()
        start_pos.setY(start_pos.y() - 40)
        label.move(start_pos.x() - label.width() // 2, start_pos.y())
        label.show()

        # 上升动画
        anim = QPropertyAnimation(label, b"pos", self.pet_ref)
        anim.setDuration(1200)
        anim.setStartValue(start_pos)
        anim.setEndValue(QPoint(start_pos.x(), start_pos.y() - 60))
        anim.setEasingCurve(QEasingCurve.OutQuad)

        # 淡出动画
        opacity = QGraphicsOpacityEffect(label)
        label.setGraphicsEffect(opacity)
        fade = QPropertyAnimation(opacity, b"opacity", self.pet_ref)
        fade.setDuration(1200)
        fade.setStartValue(1.0)
        fade.setEndValue(0.0)
        fade.setEasingCurve(QEasingCurve.InQuad)

        # 动画完成后删除
        def cleanup():
            label.deleteLater()
        fade.finished.connect(cleanup)

        anim.start()
        fade.start()
