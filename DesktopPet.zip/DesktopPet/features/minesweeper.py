from PyQt5.QtWidgets import (QWidget, QGridLayout, QPushButton, QMessageBox,
                             QVBoxLayout, QLabel)
from PyQt5.QtCore import Qt, QTimer
import random


class MinesweeperWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setAttribute(Qt.WA_QuitOnClose, False)
        self.setWindowTitle("扫雷小游戏")

        # 游戏参数
        self.rows = 8
        self.cols = 8
        self.mines = 10
        self.buttons = []
        self.mine_positions = set()
        self.revealed = set()
        self.flagged = set()
        self.game_over = False

        self.init_ui()
        self.reset_game()

    def init_ui(self):
        layout = QVBoxLayout()

        # 信息栏
        info_layout = QGridLayout()
        self.mine_label = QLabel(f"地雷: {self.mines}")
        self.status_label = QLabel("游戏开始!")
        info_layout.addWidget(self.mine_label, 0, 0)
        info_layout.addWidget(self.status_label, 0, 1)
        layout.addLayout(info_layout)

        # 游戏网格
        self.grid_layout = QGridLayout()
        self.grid_layout.setSpacing(2)
        layout.addLayout(self.grid_layout)

        # 重置按钮
        self.reset_btn = QPushButton("重新开始")
        self.reset_btn.clicked.connect(self.reset_game)
        layout.addWidget(self.reset_btn)

        self.setLayout(layout)
        self.setFixedSize(300, 350)

    def create_buttons(self):
        # 清除现有按钮
        while self.grid_layout.count():
            item = self.grid_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()
        self.buttons = []

        # 创建新按钮
        for i in range(self.rows):
            row = []
            for j in range(self.cols):
                btn = QPushButton()
                btn.setFixedSize(30, 30)
                # 绑定左键点击事件
                btn.clicked.connect(lambda checked, x=i, y=j: self.on_click(x, y))
                # 保存原始鼠标按下事件
                original_mouse_press = btn.mousePressEvent

                # 自定义鼠标按下事件处理（区分左右键）
                def mouse_press_wrapper(e, x=i, y=j, original=original_mouse_press):
                    if e.button() == Qt.RightButton:
                        # 右键处理标记功能
                        self.toggle_flag(x, y)
                        e.accept()  # 拦截右键事件，避免传递给默认处理
                    else:
                        # 左键事件交给原始处理函数（保证clicked信号能触发）
                        original(e)

                btn.mousePressEvent = mouse_press_wrapper
                self.grid_layout.addWidget(btn, i, j)
                row.append(btn)
            self.buttons.append(row)

    def reset_game(self):
        self.game_over = False
        self.mine_positions = set()
        self.revealed = set()
        self.flagged = set()
        self.create_buttons()
        self.place_mines()
        self.status_label.setText("游戏开始!")
        self.update_mine_label()

    def place_mines(self):
        # 随机放置地雷
        count = 0
        while count < self.mines:
            x = random.randint(0, self.rows - 1)
            y = random.randint(0, self.cols - 1)
            if (x, y) not in self.mine_positions:
                self.mine_positions.add((x, y))
                count += 1

    def toggle_flag(self, x, y):
        if self.game_over or (x, y) in self.revealed:
            return

        if (x, y) in self.flagged:
            self.flagged.remove((x, y))
            self.buttons[x][y].setText("")
            self.buttons[x][y].setStyleSheet("")
        else:
            self.flagged.add((x, y))
            self.buttons[x][y].setText("F")
            self.buttons[x][y].setStyleSheet("background-color: yellow;")

        self.update_mine_label()
        self.check_win()

    def update_mine_label(self):
        remaining = self.mines - len(self.flagged)
        self.mine_label.setText(f"地雷: {remaining}")

    def on_click(self, x, y):
        if self.game_over or (x, y) in self.revealed or (x, y) in self.flagged:
            return

        if (x, y) in self.mine_positions:
            self.game_over = True
            self.reveal_mines()
            self.status_label.setText("游戏结束! 踩到地雷了!")
            QMessageBox.information(self, "游戏结束", "很遗憾，你踩到地雷了！")
            return

        # 计算周围地雷数量
        count = self.count_adjacent_mines(x, y)
        self.revealed.add((x, y))
        self.buttons[x][y].setEnabled(False)

        if count > 0:
            self.buttons[x][y].setText(str(count))
            # 设置不同数字的颜色
            colors = {1: "blue", 2: "green", 3: "red", 4: "purple", 5: "maroon", 6: "teal", 7: "black", 8: "gray"}
            self.buttons[x][y].setStyleSheet(f"color: {colors[count]};")
        else:
            # 递归揭示空白区域
            self.reveal_blank(x, y)

        self.check_win()

    def count_adjacent_mines(self, x, y):
        count = 0
        for dx in [-1, 0, 1]:
            for dy in [-1, 0, 1]:
                if dx == 0 and dy == 0:
                    continue
                nx, ny = x + dx, y + dy
                if 0 <= nx < self.rows and 0 <= ny < self.cols:
                    if (nx, ny) in self.mine_positions:
                        count += 1
        return count

    def reveal_blank(self, x, y):
        for dx in [-1, 0, 1]:
            for dy in [-1, 0, 1]:
                if dx == 0 and dy == 0:
                    continue
                nx, ny = x + dx, y + dy
                if 0 <= nx < self.rows and 0 <= ny < self.cols and (nx, ny) not in self.revealed:
                    self.on_click(nx, ny)

    def reveal_mines(self):
        for (x, y) in self.mine_positions:
            self.buttons[x][y].setText("*")
            self.buttons[x][y].setStyleSheet("background-color: red;")

        # 显示错误标记
        for (x, y) in self.flagged:
            if (x, y) not in self.mine_positions:
                self.buttons[x][y].setText("X")
                self.buttons[x][y].setStyleSheet("background-color: orange;")

    def check_win(self):
        # 所有非地雷区域都被揭示则获胜
        safe_cells = self.rows * self.cols - self.mines
        if len(self.revealed) == safe_cells:
            self.game_over = True
            self.status_label.setText("恭喜胜利!")
            # 标记所有地雷
            for (x, y) in self.mine_positions:
                if (x, y) not in self.flagged:
                    self.flagged.add((x, y))
                    self.buttons[x][y].setText("F")
                    self.buttons[x][y].setStyleSheet("background-color: yellow;")
            QMessageBox.information(self, "游戏胜利", "恭喜你，成功扫除所有地雷！")