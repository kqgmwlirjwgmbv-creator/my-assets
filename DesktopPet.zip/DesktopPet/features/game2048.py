from PyQt5.QtWidgets import (QWidget, QGridLayout, QLabel, QMessageBox,
                             QVBoxLayout, QPushButton)
from PyQt5.QtCore import Qt, QSize, QPoint
from PyQt5.QtGui import QFont
import random


class Game2048(QWidget):
    def __init__(self):
        super().__init__()
        self.setAttribute(Qt.WA_QuitOnClose, False)
        self.setWindowTitle("2048小游戏（鼠标操作）")
        self.setFixedSize(400, 500)

        # 游戏初始化
        self.grid_size = 4
        self.board = [[0 for _ in range(self.grid_size)] for _ in range(self.grid_size)]
        self.score = 0
        self.high_score = 0
        self.game_over = False
        self.win = False

        # 鼠标拖拽相关变量
        self.drag_start = QPoint()
        self.dragging = False

        self.init_ui()
        self.load_high_score()
        self.start_new_game()

    def init_ui(self):
        # 主布局
        main_layout = QVBoxLayout()

        # 分数显示
        score_layout = QGridLayout()
        self.score_label = QLabel(f"分数: 0")
        self.score_label.setFont(QFont("Arial", 16, QFont.Bold))
        self.high_score_label = QLabel(f"最高分: 0")
        self.high_score_label.setFont(QFont("Arial", 16, QFont.Bold))

        score_layout.addWidget(self.score_label, 0, 0)
        score_layout.addWidget(self.high_score_label, 0, 1)
        main_layout.addLayout(score_layout)

        # 游戏网格 - 使用QWidget作为容器接收鼠标事件
        self.grid_container = QWidget()
        self.grid_container.setStyleSheet("background-color: #bbada0; border-radius: 10px;")
        self.grid_layout = QGridLayout(self.grid_container)
        self.grid_layout.setSpacing(10)
        self.grid_layout.setContentsMargins(20, 20, 20, 20)

        # 创建网格单元格
        self.cell_labels = []
        for i in range(self.grid_size):
            row = []
            for j in range(self.grid_size):
                label = QLabel()
                label.setAlignment(Qt.AlignCenter)
                label.setFont(QFont("Arial", 20, QFont.Bold))
                label.setMinimumSize(QSize(80, 80))
                self.set_cell_style(label, 0)
                self.grid_layout.addWidget(label, i, j)
                row.append(label)
            self.cell_labels.append(row)

        main_layout.addWidget(self.grid_container)

        # 控制按钮
        btn_layout = QGridLayout()

        self.new_game_btn = QPushButton("新游戏")
        self.new_game_btn.clicked.connect(self.start_new_game)
        btn_layout.addWidget(self.new_game_btn, 0, 0, 1, 2)

        self.quit_btn = QPushButton("退出")
        self.quit_btn.clicked.connect(self.close)
        btn_layout.addWidget(self.quit_btn, 0, 2, 1, 2)

        main_layout.addLayout(btn_layout)

        self.setLayout(main_layout)

    # 鼠标事件处理 - 开始拖拽
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton and self.grid_container.geometry().contains(event.pos()):
            self.drag_start = event.pos()
            self.dragging = True

    # 鼠标事件处理 - 结束拖拽并判断方向
    def mouseReleaseEvent(self, event):
        if self.dragging and event.button() == Qt.LeftButton:
            self.dragging = False
            drag_end = event.pos()

            # 计算拖拽距离
            dx = drag_end.x() - self.drag_start.x()
            dy = drag_end.y() - self.drag_start.y()

            # 判断拖拽方向（通过比较水平和垂直拖拽距离）
            # 设置最小拖拽距离阈值，避免误操作
            min_distance = 20

            if abs(dx) > abs(dy) and abs(dx) > min_distance:
                if dx > 0:
                    # 向右拖拽
                    self.handle_move("right")
                else:
                    # 向左拖拽
                    self.handle_move("left")
            elif abs(dy) > abs(dx) and abs(dy) > min_distance:
                if dy > 0:
                    # 向下拖拽
                    self.handle_move("down")
                else:
                    # 向上拖拽
                    self.handle_move("up")

    # 处理移动逻辑
    def handle_move(self, direction):
        if self.game_over:
            return

        moved = self.move(direction)
        if moved:
            self.generate_new_number()
            self.update_board()
            if not self.can_move():
                self.game_over = True
                self.update_board()

    def set_cell_style(self, label, value):
        styles = {
            0: ("#cdc1b4", "#cdc1b4", ""),
            2: ("#eee4da", "#776e65", "2"),
            4: ("#ede0c8", "#776e65", "4"),
            8: ("#f2b179", "#f9f6f2", "8"),
            16: ("#f59563", "#f9f6f2", "16"),
            32: ("#f67c5f", "#f9f6f2", "32"),
            64: ("#f65e3b", "#f9f6f2", "64"),
            128: ("#edcf72", "#f9f6f2", "128"),
            256: ("#edcc61", "#f9f6f2", "256"),
            512: ("#edc850", "#f9f6f2", "512"),
            1024: ("#edc53f", "#f9f6f2", "1024"),
            2048: ("#edc22e", "#f9f6f2", "2048"),
            "higher": ("#3c3a32", "#f9f6f2", "")
        }

        if value == 0:
            bg_color, text_color, text = styles[0]
        elif value >= 4096:
            bg_color, text_color, _ = styles["higher"]
            text = str(value)
        else:
            bg_color, text_color, text = styles[value]

        label.setStyleSheet(f"background-color: {bg_color}; color: {text_color}; border-radius: 5px;")
        label.setText(text)

    def start_new_game(self):
        self.board = [[0 for _ in range(self.grid_size)] for _ in range(self.grid_size)]
        self.score = 0
        self.game_over = False
        self.win = False
        self.update_score()
        self.generate_new_number()
        self.generate_new_number()
        self.update_board()

    def generate_new_number(self):
        empty_cells = []
        for i in range(self.grid_size):
            for j in range(self.grid_size):
                if self.board[i][j] == 0:
                    empty_cells.append((i, j))

        if empty_cells:
            i, j = random.choice(empty_cells)
            self.board[i][j] = 2 if random.random() < 0.9 else 4
            return True
        return False

    def update_board(self):
        for i in range(self.grid_size):
            for j in range(self.grid_size):
                value = self.board[i][j]
                self.set_cell_style(self.cell_labels[i][j], value)

        if not self.win and any(2048 in row for row in self.board):
            self.win = True
            QMessageBox.information(self, "恭喜", f"你赢了！分数: {self.score}")

        if self.game_over:
            QMessageBox.information(self, "游戏结束", f"游戏结束！你的分数是: {self.score}")

    def update_score(self):
        self.score_label.setText(f"分数: {self.score}")
        if self.score > self.high_score:
            self.high_score = self.score
            self.high_score_label.setText(f"最高分: {self.high_score}")
            self.save_high_score()

    def load_high_score(self):
        try:
            with open("high_score.txt", "r") as f:
                self.high_score = int(f.read())
                self.high_score_label.setText(f"最高分: {self.high_score}")
        except:
            self.high_score = 0

    def save_high_score(self):
        with open("high_score.txt", "w") as f:
            f.write(str(self.high_score))

    def move(self, direction):
        moved = False
        original_board = [row.copy() for row in self.board]

        if direction == "left":
            for i in range(self.grid_size):
                self._process_row_left(i)
        elif direction == "right":
            for i in range(self.grid_size):
                self._process_row_right(i)
        elif direction == "up":
            for j in range(self.grid_size):
                self._process_col_up(j)
        elif direction == "down":
            for j in range(self.grid_size):
                self._process_col_down(j)

        moved = original_board != self.board
        if moved:
            self.update_score()
        return moved

    def _process_row_left(self, row):
        self._collapse_row(row)
        for j in range(self.grid_size - 1):
            if self.board[row][j] != 0 and self.board[row][j] == self.board[row][j + 1]:
                self.board[row][j] *= 2
                self.score += self.board[row][j]
                self.board[row][j + 1] = 0
        self._collapse_row(row)

    def _process_row_right(self, row):
        self._expand_row(row)
        for j in range(self.grid_size - 1, 0, -1):
            if self.board[row][j] != 0 and self.board[row][j] == self.board[row][j - 1]:
                self.board[row][j] *= 2
                self.score += self.board[row][j]
                self.board[row][j - 1] = 0
        self._expand_row(row)

    def _process_col_up(self, col):
        self._collapse_col(col)
        for i in range(self.grid_size - 1):
            if self.board[i][col] != 0 and self.board[i][col] == self.board[i + 1][col]:
                self.board[i][col] *= 2
                self.score += self.board[i][col]
                self.board[i + 1][col] = 0
        self._collapse_col(col)

    def _process_col_down(self, col):
        self._expand_col(col)
        for i in range(self.grid_size - 1, 0, -1):
            if self.board[i][col] != 0 and self.board[i][col] == self.board[i - 1][col]:
                self.board[i][col] *= 2
                self.score += self.board[i][col]
                self.board[i - 1][col] = 0
        self._expand_col(col)

    def _collapse_row(self, row):
        new_row = [num for num in self.board[row] if num != 0]
        new_row += [0] * (self.grid_size - len(new_row))
        self.board[row] = new_row

    def _expand_row(self, row):
        new_row = [num for num in self.board[row] if num != 0]
        new_row = [0] * (self.grid_size - len(new_row)) + new_row
        self.board[row] = new_row

    def _collapse_col(self, col):
        new_col = [self.board[i][col] for i in range(self.grid_size) if self.board[i][col] != 0]
        new_col += [0] * (self.grid_size - len(new_col))
        for i in range(self.grid_size):
            self.board[i][col] = new_col[i]

    def _expand_col(self, col):
        new_col = [self.board[i][col] for i in range(self.grid_size) if self.board[i][col] != 0]
        new_col = [0] * (self.grid_size - len(new_col)) + new_col
        for i in range(self.grid_size):
            self.board[i][col] = new_col[i]

    def can_move(self):
        for i in range(self.grid_size):
            for j in range(self.grid_size):
                if self.board[i][j] == 0:
                    return True

        for i in range(self.grid_size):
            for j in range(self.grid_size - 1):
                if self.board[i][j] == self.board[i][j + 1]:
                    return True

        for j in range(self.grid_size):
            for i in range(self.grid_size - 1):
                if self.board[i][j] == self.board[i + 1][j]:
                    return True

        return False


if __name__ == "__main__":
    import sys
    from PyQt5.QtWidgets import QApplication

    app = QApplication(sys.argv)
    game = Game2048()
    game.show()
    sys.exit(app.exec_())