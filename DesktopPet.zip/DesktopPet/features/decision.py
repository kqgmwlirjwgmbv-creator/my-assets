from PyQt5.QtWidgets import QWidget, QVBoxLayout, QPushButton, QMessageBox
from PyQt5.QtCore import Qt
import random

class DecisionWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setAttribute(Qt.WA_QuitOnClose, False)
        self.setWindowTitle("事件决定器")
        self.setFixedSize(250, 150)
        layout = QVBoxLayout()
        btn = QPushButton("随机决定！")
        btn.clicked.connect(self.decide)
        layout.addWidget(btn)
        self.setLayout(layout)

    def decide(self):
        choice = random.choice(["选项A", "选项B", "选项C"])
        QMessageBox.information(self, "结果", f"决定是：{choice}")
