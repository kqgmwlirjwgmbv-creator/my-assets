from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QInputDialog, QMessageBox
from PyQt5.QtCore import Qt, QTimer, QTime


class TimerWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setAttribute(Qt.WA_QuitOnClose, False)
        self.setWindowTitle("倒计时")
        self.setFixedSize(250, 150)

        # 初始化倒计时相关变量
        self.remaining_seconds = 0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_countdown)

        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        # 显示倒计时的标签
        self.label = QLabel("点击按钮设置倒计时", self)
        self.label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.label)

        # 开始倒计时的按钮
        self.start_btn = QPushButton("设置倒计时", self)
        self.start_btn.clicked.connect(self.set_countdown)
        layout.addWidget(self.start_btn)

        self.setLayout(layout)

    def set_countdown(self):
        # 弹出输入对话框，获取用户输入的秒数
        seconds, ok = QInputDialog.getInt(
            self,
            "设置倒计时",
            "请输入倒计时秒数:",
            60,  # 默认值
            1,  # 最小值
            3600  # 最大值（1小时）
        )

        if ok:
            self.remaining_seconds = seconds
            self.update_display()
            self.timer.start(1000)  # 每秒触发一次
            self.start_btn.setText("倒计时中...")
            self.start_btn.setEnabled(False)

    def update_countdown(self):
        # 更新剩余时间
        self.remaining_seconds -= 1
        self.update_display()

        # 倒计时结束
        if self.remaining_seconds <= 0:
            self.timer.stop()
            QMessageBox.information(self, "提示", "时间到啦.")
            self.label.setText("点击按钮设置倒计时")
            self.start_btn.setText("设置倒计时")
            self.start_btn.setEnabled(True)

    def update_display(self):
        # 格式化显示时间（分:秒）
        minutes = self.remaining_seconds // 60
        seconds = self.remaining_seconds % 60
        self.label.setText(f"{minutes:02d}:{seconds:02d}")