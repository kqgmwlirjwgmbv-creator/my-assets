import math
from PyQt5.QtWidgets import QWidget, QPushButton
from PyQt5.QtCore import Qt, QPoint

from features.memo import MemoWindow
from features.decision import DecisionWindow
from features.timer import TimerWindow
from features.minesweeper import MinesweeperWindow
from features.game2048 import Game2048
from features.play import PlayWindow  # ✅ 新增导入


class RadialMenu(QWidget):
    def __init__(self, pet_ref=None):  # ✅ 新增 pet_ref 参数
        super().__init__()
        self.pet_ref = pet_ref  # 保存宠物引用
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.SubWindow)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.resize(300, 300)
        self.buttons = []
        self.window_instances = {}
        self.create_buttons()

    def create_buttons(self):
        """创建功能按钮"""

        funcs = [
            ("备忘录", MemoWindow),
            ("事件决定器", DecisionWindow),
            ("倒计时", TimerWindow),
            ("扫雷", MinesweeperWindow),
            ("2048游戏", Game2048),
            ("玩耍", PlayWindow),  # ✅ 新增玩耍功能
        ]

        radius = 100
        center = QPoint(150, 150)
        angle_step = 360 / len(funcs)

        for i, (text, win_cls) in enumerate(funcs):
            angle = math.radians(i * angle_step)
            x = center.x() + radius * math.cos(angle) - 40
            y = center.y() + radius * math.sin(angle) - 20
            btn = QPushButton(text, self)
            btn.setGeometry(int(x), int(y), 80, 40)
            btn.clicked.connect(lambda checked=False, c=win_cls: self.open_window(c))
            self.buttons.append(btn)

    def open_window(self, cls):
        """统一窗口打开逻辑"""
        # ✅ 特殊处理 PlayWindow（不弹窗，而是显示动画）
        if cls == PlayWindow:
            if self.pet_ref:
                play = PlayWindow(self.pet_ref)
                play.show_play_effect()
            return

        # ✅ 其他功能窗口常规显示
        if cls not in self.window_instances:
            self.window_instances[cls] = cls()
        self.window_instances[cls].show()
        self.window_instances[cls].raise_()
