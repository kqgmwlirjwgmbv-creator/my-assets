from PyQt5.QtWidgets import QLabel, QMenu, QAction
from PyQt5.QtCore import Qt, QTimer, QPoint
from PyQt5.QtGui import QPixmap
from radial_menu import RadialMenu


class DesktopPet(QLabel):
    def __init__(self):
        super().__init__()

        # 设置宠物图像
        self.setPixmap(QPixmap("assets/catmwew.png").scaled(
            128, 128, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.SubWindow)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.show()

        # ✅ 传入宠物引用，供玩耍动画使用
        self.radial_menu = RadialMenu(pet_ref=self)

        # 拖拽控制
        self.dragging = False
        self.press_timer = QTimer(self)
        self.press_timer.setSingleShot(True)
        self.press_timer.timeout.connect(self.start_drag)
        self.offset = QPoint()

    # 鼠标按下
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.press_timer.start(300)  # 300ms 判断长按
            self.offset = event.globalPos() - self.pos()
        elif event.button() == Qt.RightButton:
            self.show_menu(event.globalPos())

    # 鼠标释放
    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            if self.press_timer.isActive():  # 短按
                self.press_timer.stop()
                self.toggle_radial_menu()
            else:  # 长按结束
                self.dragging = False

    # 鼠标移动
    def mouseMoveEvent(self, event):
        if self.dragging:
            self.move(event.globalPos() - self.offset)

    def start_drag(self):
        self.dragging = True

    def show_menu(self, pos):
        menu = QMenu()
        action_exit = QAction("退出", self)
        action_exit.triggered.connect(self.close_app)
        menu.addAction(action_exit)
        menu.exec_(pos)

    def close_app(self):
        self.radial_menu.close()
        self.close()

    def toggle_radial_menu(self):
        """切换功能轮盘显示"""
        if self.radial_menu.isVisible():
            self.radial_menu.hide()
        else:
            center = self.mapToGlobal(self.rect().center())
            self.radial_menu.move(center.x() - 150, center.y() - 150)
            self.radial_menu.show()
