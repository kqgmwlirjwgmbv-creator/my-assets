import sys
from PyQt5.QtWidgets import QApplication, QLabel, QMenu, QAction, QWidget
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import Qt, QPoint

class Pet(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground, True)

        # 加载宠物图片（png/gif）
        self.label = QLabel(self)
        self.label.setPixmap(QPixmap("pet.png"))
        self.resize(self.label.pixmap().size())

        # 右键菜单
        self.menu = QMenu(self)
        self.menu.addAction(QAction("事件决定器", self))
        self.menu.addAction(QAction("备忘录", self))
        self.menu.addAction(QAction("退出", self, triggered=self.close))

    def mousePressEvent(self, event):
        if event.button() == Qt.RightButton:
            self.menu.exec_(event.globalPos())
        elif event.button() == Qt.LeftButton:
            print("点击了宠物，可以触发功能面板")
            # 这里可以写打开你们的助手窗口的逻辑

if __name__ == '__main__':
    app = QApplication(sys.argv)
    pet = Pet()
    pet.show()
    sys.exit(app.exec_())
